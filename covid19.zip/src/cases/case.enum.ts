export enum Gender {
  MALE = 'MALE',
  FEMALE = 'FEMALE',
  NA = 'n/a',
};

export enum Status {
  ACTIVE = 'ACTIVE',
  RECOVERED = 'RECOVERED',
  DEAD = 'DEAD',
};
